// Configuración de Firebase
const firebaseConfig = {
  apiKey: "AIzaSyBJgDqHiHD8mncuRNlw8eA1ismr_fcvj2E",
  authDomain: "mi-gestion-e2ee.firebaseapp.com",
  projectId: "mi-gestion-e2ee",
  storageBucket: "mi-gestion-e2ee.firebasestorage.app",
  messagingSenderId: "97671435614",
  appId: "1:97671435614:web:e0f35d92692ca1e63b2bcf",
};

export default firebaseConfig;
